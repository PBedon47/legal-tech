import { APIGatewayProxyEvent, APIGatewayProxyResult } from 'aws-lambda';
import { DynamoDBClient, ScanCommand, PutItemCommand } from '@aws-sdk/client-dynamodb';
import { v4 as uuidv4 } from 'uuid';

const client = new DynamoDBClient({ region: 'us-east-1' }); // Cambia la región si usas otra
const TABLE_NAME = 'tec-practicantes-todo'; // Nombre de tu tabla DynamoDB

export const handler = async (event: APIGatewayProxyEvent): Promise<APIGatewayProxyResult> => {
  try {
    if (event.httpMethod === 'GET') {
      const data = await client.send(new ScanCommand({ TableName: TABLE_NAME }));
      const items = data.Items?.map(item => ({
        id: item.id.S,
        titulo: item.titulo.S,
        completada: item.completada.BOOL
      }));

      return {
        statusCode: 200,
        body: JSON.stringify(items || []),
      };
    }

    if (event.httpMethod === 'POST') {
      if (!event.body) {
        return { statusCode: 400, body: JSON.stringify({ error: 'Cuerpo vacío' }) };
      }

      const body = JSON.parse(event.body);
      if (!body.titulo || typeof body.titulo !== 'string') {
        return { statusCode: 400, body: JSON.stringify({ error: 'El título es obligatorio y debe ser string' }) };
      }

      const newItem = {
        id: { S: uuidv4() },
        titulo: { S: body.titulo },
        completada: { BOOL: false },
      };

      await client.send(new PutItemCommand({
        TableName: TABLE_NAME,
        Item: newItem,
      }));

      return {
        statusCode: 200,
        body: JSON.stringify({ message: 'Tarea creada con éxito', id: newItem.id.S }),
      };
    }

    return { statusCode: 405, body: JSON.stringify({ error: 'Método no permitido' }) };

  } catch (error) {
    console.error(error);
    return { statusCode: 500, body: JSON.stringify({ error: 'Error interno del servidor' }) };
  }
};
